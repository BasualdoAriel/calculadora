let nombre=prompt("Ingresá tu nombre:");
let apellido=prompt("Ingresá tu apellido:");

document.write("<h3>Hola "+nombre+" "+apellido+"</h3>"+"</br>");

let primerNumero=parseInt(prompt("Ingrea un número"));
let segundoNumero= parseInt(prompt("Ingresa un segundo número"));
let resultado;
let resultadoInverso;

if (!isNaN(primerNumero)& !isNaN(segundoNumero)){
    alert("Ingresaste el número "+ primerNumero+ " y "+segundoNumero);
}else{
    alert("Alguno de los datos no es correcto, volve a ingresar los números: ");
    primerNumero= parseInt(prompt("Volvé a ingresar el primer número:"));
    segundoNumero= parseInt(prompt("Ahora ingresá el segundo número:"));
}

let operador= prompt("Ingresá un operador matemático:");

switch(operador){
    case "+":
        alert("Ingresaste el operador de suma");
        resultado=primerNumero+segundoNumero
        document.write("La suma de los números ingresados es: "+resultado);
        break;
    case "-":
        alert("Ingresaste el operador de resta");
        resultado=primerNumero-segundoNumero
        resultadoInverso=segundoNumero-primerNumero
        document.write("El resultado del primer número menos el segundo es: "+resultado+"</br>");
        document.write("El resultado de la resta del segundo número con el primero es: "+resultadoInverso);
        break;
    case "/":
        alert("Ingresaste el operador de división");
        resultado=primerNumero/segundoNumero
        resultadoInverso=segundoNumero/primerNumero
        document.write("La división del primer número con el segundo es: "+resultado+"</br>");
        document.write("La división del segundo número con el primero es: "+resultadoInverso);
        break;
    case "*":
        alert("Ingresaste el operador de multiplicación");
        resultado=primerNumero*segundoNumero
        document.write("La multuplicación de los números ingresados es: "+resultado);
        break;
    case "":
        document.write("No ingresaste un operador válido. Recargá la página");
        break;        
}

